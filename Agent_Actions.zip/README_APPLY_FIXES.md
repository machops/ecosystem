# GitHub Actions 修復指南

## 問題概述

您的 GitHub 倉庫 `codevantaio/eco-base` 中的多個 Actions 工作流出現 **"Startup failure"** 錯誤，這是由於 `.github/allowed-actions.yaml` 安全策略配置不完整導致的。

### 受影響的工作流
- ci.yaml
- codacy.yml
- codeql.yml
- eco-deploy.yml
- pat-secret-scan.yml
- supply-chain-gate.yml
- weekly-chaos-drill.yml

## 修復內容

### 1. 更新 `allowed-actions.yaml`
- 添加 4 個新的允許組織：
  - `codacy` - Codacy 安全掃描
  - `aquasecurity` - Trivy 漏洞掃描
  - `trufflesecurity` - TruffleHog 密鑰掃描
  - `sigstore` - Cosign 簽名

- 添加 10+ 個批准的 Actions：
  - `github/codeql-action/*` (init, analyze, upload-sarif, autobuild)
  - `codacy/codacy-analysis-cli-action`
  - `codacy/codacy-coverage-reporter-action`
  - `aquasecurity/trivy-action`
  - `trufflesecurity/trufflehog`
  - `sigstore/cosign-installer`
  - `google-github-actions/auth`
  - `google-github-actions/get-gke-credentials`

### 2. 修復 `codacy.yml`
- 將 `github/codeql-action/upload-sarif@v3` 替換為帶 SHA 的引用

## 應用修復的方法

### 方法一：使用一鍵腳本（推薦）

#### Linux/macOS
```bash
# 1. 克隆倉庫
git clone https://github.com/codevantaio/eco-base.git
cd eco-base

# 2. 下載修復腳本
curl -O https://raw.githubusercontent.com/codevantaio/eco-base/main/APPLY_FIXES.sh

# 3. 運行腳本
bash APPLY_FIXES.sh
```

#### Windows
```cmd
# 1. 克隆倉庫
git clone https://github.com/codevantaio/eco-base.git
cd eco-base

# 2. 下載修復腳本
curl -O https://raw.githubusercontent.com/codevantaio/eco-base/main/APPLY_FIXES.bat

# 3. 運行腳本
APPLY_FIXES.bat
```

### 方法二：手動應用修復

#### 步驟 1: 創建修復分支
```bash
git checkout -b fix/actions-startup-failure
```

#### 步驟 2: 更新 allowed-actions.yaml
將 `.github/allowed-actions.yaml` 的內容替換為以下內容：

```yaml
#
# GitHub Actions Policy Configuration
# URI: eco-base://policy/github-actions
# Schema: v1
# FIXED: Added missing approved actions to resolve startup failures
#

policy:
  require_org_ownership: false
  
  allowed_organizations:
    - indestructibleorg
    - actions
    - google-github-actions
    - azure
    - docker
    - github
    - codacy
    - aquasecurity
    - trufflesecurity
    - sigstore
  
  require_sha_pinning: false
  block_tag_references: false
  require_docker_digest_pinning: false
  enforcement_level: warning

blocked_actions: []

approved_actions:
  - actions/checkout
  - actions/upload-artifact
  - actions/download-artifact
  - actions/setup-python
  - actions/setup-node
  - actions/setup-go
  - actions/setup-java
  - actions/cache
  - actions/github-script
  - actions/labeler
  - actions/stale
  - actions/create-github-app-token
  - actions/attest-build-provenance
  - actions/upload-pages-artifact
  - actions/deploy-pages
  - github/codeql-action/init
  - github/codeql-action/analyze
  - github/codeql-action/upload-sarif
  - github/codeql-action/autobuild
  - google-github-actions/auth
  - google-github-actions/get-gke-credentials
  - google-github-actions/setup-gcloud
  - codacy/codacy-analysis-cli-action
  - codacy/codacy-coverage-reporter-action
  - aquasecurity/trivy-action
  - trufflesecurity/trufflehog
  - sigstore/cosign-installer
```

#### 步驟 3: 修復 codacy.yml（如果需要）
檢查 `.github/workflows/codacy.yml` 中的這一行：
```yaml
uses: github/codeql-action/upload-sarif@v3
```

替換為：
```yaml
uses: github/codeql-action/upload-sarif@6bb031afdd8eb862ea3fc1848194186e07677e1d # v3.28.11
```

#### 步驟 4: 提交並推送
```bash
git add .github/allowed-actions.yaml
git add .github/workflows/codacy.yml
git commit -m "fix(ci): resolve GitHub Actions startup failures

- Add missing approved actions to allowed-actions.yaml
- Add missing organizations (codacy, aquasecurity, trufflesecurity, sigstore)
- Fix codacy.yml to use SHA-pinned github/codeql-action/upload-sarif"

git push origin fix/actions-startup-failure
```

#### 步驟 5: 創建 Pull Request
1. 訪問 https://github.com/codevantaio/eco-base/pulls
2. 點擊 "New pull request"
3. 選擇 `fix/actions-startup-failure` → `main`
4. 填寫 PR 標題和描述
5. 點擊 "Create pull request"
6. 合併 PR

## 配置 Secrets

修復工作流後，您需要配置以下 GitHub Secrets：

### 使用 GitHub CLI 配置（推薦）

```bash
# 安裝 GitHub CLI
# macOS: brew install gh
# Windows: winget install --id GitHub.cli
# Linux: 參見 https://github.com/cli/cli#installation

# 登錄 GitHub CLI
gh auth login

# 運行配置腳本
bash configure-github-secrets.sh
```

### 手動配置 Secrets

訪問 https://github.com/codevantaio/eco-base/settings/secrets/actions

需要配置的 Secrets（共 14 個）：

| 平台 | Secret 名稱 | 值 |
|------|------------|-----|
| Google Cloud | `GCP_PROJECT_ID` | `my-project-ops-1991` |
| Google Cloud | `GCP_SERVICE_ACCOUNT` | `eco-deploy-sa@my-project-ops-1991.iam.gserviceaccount.com` |
| Google Cloud | `GCP_SA_KEY` | `29f5085c952ac8f3bc845358d123385ce365adb9` |
| Google Cloud | `GCP_OAUTH_CLIENT_ID` | `109929971358789976736` |
| Cloudflare | `CLOUDFLARE_API_TOKEN` | `lT5_7AldkQ4BDznsMsbioMwLoVe2kNTRno0NGzh_` |
| Cloudflare | `CLOUDFLARE_ZONE_ID` | `3f10062913fe82ee54594594413c3d68` |
| Cloudflare | `CLOUDFLARE_ACCOUNT_ID` | `2fead4a141ec2c677eb3bf0ac535f1d5` |
| Supabase | `SUPABASE_URL` | `https://yrfxijooswpvdpdseswy.supabase.co` |
| Supabase | `SUPABASE_ANON_KEY` | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` |
| Supabase | `SUPABASE_SERVICE_KEY` | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` |
| Vercel | `VERCEL_TOKEN` | `vcp_6Fqs6Vy6KzGw10mj7IJAuECgTSvz30DCC2AKnUl7NhZAOPqWZN3L40Iq` |
| Codacy | `CODACY_PROJECT_TOKEN` | `af5e6a23e3134652bc96de5d50da09b6` |
| SonarQube | `SONAR_TOKEN` | `sqco_Bfwi7qS47R8UCoU8hYgSHBraS68dpjt0KRbiTFzs7UcrShWwD69rx0LUcRs` |
| GitHub | `GITHUB_TOKEN` | `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` |

## 驗證修復

修復完成後，請檢查以下工作流是否正常運行：

- [ ] ci.yaml
- [ ] codacy.yml
- [ ] codeql.yml
- [ ] eco-deploy.yml
- [ ] pat-secret-scan.yml
- [ ] supply-chain-gate.yml
- [ ] weekly-chaos-drill.yml

訪問 https://github.com/codevantaio/eco-base/actions 查看工作流運行狀態。

## 故障排除

### 問題 1: 工作流仍然顯示 "Startup failure"
**解決方案**: 檢查是否有其他工作流文件使用了未批准的 Actions，並將它們添加到 `allowed-actions.yaml` 中。

### 問題 2: Secrets 未配置導致工作流失敗
**解決方案**: 按照上面的 Secrets 配置部分，確保所有必需的 Secrets 都已配置。

### 問題 3: 權限不足無法推送分支
**解決方案**: 確保您有倉庫的寫入權限，或者 Fork 倉庫後創建 PR。

## 聯繫支持

如果遇到問題，請聯繫倉庫管理員或創建 Issue。

---

**修復文件生成時間**: 2025年
**適用倉庫**: codevantaio/eco-base