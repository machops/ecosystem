# GitHub Secrets 配置清单

## 仓库信息
- **仓库地址**: https://github.com/codevantaio/eco-base
- **配置日期**: 2025年
- **配置方式**: GitHub CLI (gh)

---

## Secrets 配置详情

### 1. Google Cloud Platform (GCP) - 4个 Secrets

| Secret 名称 | 值 | 用途 |
|------------|-----|------|
| `GCP_PROJECT_ID` | `my-project-ops-1991` | GCP 项目 ID |
| `GCP_SERVICE_ACCOUNT` | `eco-deploy-sa@my-project-ops-1991.iam.gserviceaccount.com` | 服务账号邮箱 |
| `GCP_SA_KEY` | `29f5085c952ac8f3bc845358d123385ce365adb9` | 服务账号密钥 |
| `GCP_OAUTH_CLIENT_ID` | `109929971358789976736` | OAuth 客户端 ID |

**设置命令:**
```bash
gh secret set GCP_PROJECT_ID --body "my-project-ops-1991" --repo codevantaio/eco-base
gh secret set GCP_SERVICE_ACCOUNT --body "eco-deploy-sa@my-project-ops-1991.iam.gserviceaccount.com" --repo codevantaio/eco-base
gh secret set GCP_SA_KEY --body "29f5085c952ac8f3bc845358d123385ce365adb9" --repo codevantaio/eco-base
gh secret set GCP_OAUTH_CLIENT_ID --body "109929971358789976736" --repo codevantaio/eco-base
```

---

### 2. Cloudflare - 3个 Secrets

| Secret 名称 | 值 | 用途 |
|------------|-----|------|
| `CLOUDFLARE_API_TOKEN` | `lT5_7AldkQ4BDznsMsbioMwLoVe2kNTRno0NGzh_` | API 令牌 |
| `CLOUDFLARE_ZONE_ID` | `3f10062913fe82ee54594594413c3d68` | Zone ID |
| `CLOUDFLARE_ACCOUNT_ID` | `2fead4a141ec2c677eb3bf0ac535f1d5` | 账号 ID |

**设置命令:**
```bash
gh secret set CLOUDFLARE_API_TOKEN --body "lT5_7AldkQ4BDznsMsbioMwLoVe2kNTRno0NGzh_" --repo codevantaio/eco-base
gh secret set CLOUDFLARE_ZONE_ID --body "3f10062913fe82ee54594594413c3d68" --repo codevantaio/eco-base
gh secret set CLOUDFLARE_ACCOUNT_ID --body "2fead4a141ec2c677eb3bf0ac535f1d5" --repo codevantaio/eco-base
```

---

### 3. Supabase - 3个 Secrets

| Secret 名称 | 值 | 用途 |
|------------|-----|------|
| `SUPABASE_URL` | `https://yrfxijooswpvdpdseswy.supabase.co` | Supabase 项目 URL |
| `SUPABASE_ANON_KEY` | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` | 匿名密钥 |
| `SUPABASE_SERVICE_KEY` | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` | 服务密钥 |

**设置命令:**
```bash
gh secret set SUPABASE_URL --body "https://yrfxijooswpvdpdseswy.supabase.co" --repo codevantaio/eco-base
gh secret set SUPABASE_ANON_KEY --body "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlyZnhpam9vc3dwdmRwZHNlc3d5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA3MjYxNjMsImV4cCI6MjA2MzAyMTYzfQ.R4gO5Kj5G0aYnvOE3N4D3gBN1Zu7fD9d31z99qW023I" --repo codevantaio/eco-base
gh secret set SUPABASE_SERVICE_KEY --body "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlyZnhpam9vc3dwdmRwZHNlc3d5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MDcyNjE2MywiZXhwIjoyMDg2MzAyMTYzfQ.-OGp0mC6K3iJzk5-oWl6LsbQpkBwk8yTPMa-hEL74MQ" --repo codevantaio/eco-base
```

---

### 4. Vercel - 1个 Secret

| Secret 名称 | 值 | 用途 |
|------------|-----|------|
| `VERCEL_TOKEN` | `vcp_6Fqs6Vy6KzGw10mj7IJAuECgTSvz30DCC2AKnUl7NhZAOPqWZN3L40Iq` | Vercel 部署令牌 |

**设置命令:**
```bash
gh secret set VERCEL_TOKEN --body "vcp_6Fqs6Vy6KzGw10mj7IJAuECgTSvz30DCC2AKnUl7NhZAOPqWZN3L40Iq" --repo codevantaio/eco-base
```

---

### 5. Codacy - 1个 Secret

| Secret 名称 | 值 | 用途 |
|------------|-----|------|
| `CODACY_PROJECT_TOKEN` | `af5e6a23e3134652bc96de5d50da09b6` | Codacy 项目令牌 |

**设置命令:**
```bash
gh secret set CODACY_PROJECT_TOKEN --body "af5e6a23e3134652bc96de5d50da09b6" --repo codevantaio/eco-base
```

---

### 6. SonarQube - 1个 Secret

| Secret 名称 | 值 | 用途 |
|------------|-----|------|
| `SONAR_TOKEN` | `sqco_Bfwi7qS47R8UCoU8hYgSHBraS68dpjt0KRbiTFzs7UcrShWwD69rx0LUcRs` | SonarQube 令牌 |

**设置命令:**
```bash
gh secret set SONAR_TOKEN --body "sqco_Bfwi7qS47R8UCoU8hYgSHBraS68dpjt0KRbiTFzs7UcrShWwD69rx0LUcRs" --repo codevantaio/eco-base
```

---

### 7. GitHub - 1个 Secret

| Secret 名称 | 值 | 用途 |
|------------|-----|------|
| `GITHUB_TOKEN` | `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` | CI/CD PAT |

**设置命令:**
```bash
gh secret set GITHUB_TOKEN --body "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" --repo codevantaio/eco-base
```

---

## 快速配置（一键脚本）

### 方法 1: 使用提供的脚本
```bash
# 下载并运行配置脚本
bash configure-github-secrets.sh
```

### 方法 2: 手动批量配置
```bash
# 登录 GitHub CLI
echo "YOUR_PAT" | gh auth login --with-token

# 设置所有 Secrets (复制以下所有命令)
gh secret set GCP_PROJECT_ID --body "my-project-ops-1991" --repo codevantaio/eco-base
gh secret set GCP_SERVICE_ACCOUNT --body "eco-deploy-sa@my-project-ops-1991.iam.gserviceaccount.com" --repo codevantaio/eco-base
gh secret set GCP_SA_KEY --body "29f5085c952ac8f3bc845358d123385ce365adb9" --repo codevantaio/eco-base
gh secret set GCP_OAUTH_CLIENT_ID --body "109929971358789976736" --repo codevantaio/eco-base
gh secret set CLOUDFLARE_API_TOKEN --body "lT5_7AldkQ4BDznsMsbioMwLoVe2kNTRno0NGzh_" --repo codevantaio/eco-base
gh secret set CLOUDFLARE_ZONE_ID --body "3f10062913fe82ee54594594413c3d68" --repo codevantaio/eco-base
gh secret set CLOUDFLARE_ACCOUNT_ID --body "2fead4a141ec2c677eb3bf0ac535f1d5" --repo codevantaio/eco-base
gh secret set SUPABASE_URL --body "https://yrfxijooswpvdpdseswy.supabase.co" --repo codevantaio/eco-base
gh secret set SUPABASE_ANON_KEY --body "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlyZnhpam9vc3dwdmRwZHNlc3d5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA3MjYxNjMsImV4cCI6MjA4NjMwMjE2M30.R4gO5Kj5G0aYnvOE3N4D3gBN1Zu7fD9d31z99qW023I" --repo codevantaio/eco-base
gh secret set SUPABASE_SERVICE_KEY --body "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlyZnhpam9vc3dwdmRwZHNlc3d5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MDcyNjE2MywiZXhwIjoyMDg2MzAyMTYzfQ.-OGp0mC6K3iJzk5-oWl6LsbQpkBwk8yTPMa-hEL74MQ" --repo codevantaio/eco-base
gh secret set VERCEL_TOKEN --body "vcp_6Fqs6Vy6KzGw10mj7IJAuECgTSvz30DCC2AKnUl7NhZAOPqWZN3L40Iq" --repo codevantaio/eco-base
gh secret set CODACY_PROJECT_TOKEN --body "af5e6a23e3134652bc96de5d50da09b6" --repo codevantaio/eco-base
gh secret set SONAR_TOKEN --body "sqco_Bfwi7qS47R8UCoU8hYgSHBraS68dpjt0KRbiTFzs7UcrShWwD69rx0LUcRs" --repo codevantaio/eco-base
gh secret set GITHUB_TOKEN --body "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" --repo codevantaio/eco-base
```

---

## 验证配置

### 查看所有 Secrets
```bash
gh secret list --repo codevantaio/eco-base
```

### 验证特定 Secret
```bash
gh secret list --repo codevantaio/eco-base | grep GCP_PROJECT_ID
```

---

## Secrets 统计

| 平台 | Secrets 数量 |
|------|-------------|
| Google Cloud | 4 |
| Cloudflare | 3 |
| Supabase | 3 |
| Vercel | 1 |
| Codacy | 1 |
| SonarQube | 1 |
| GitHub | 1 |
| **总计** | **14** |

---

## 安全注意事项

1. **所有 Secrets 已加密存储** - GitHub 使用 libsodium 密封箱加密
2. **Secrets 在日志中自动屏蔽** - GitHub Actions 会自动隐藏 Secrets
3. **定期轮换密钥** - 建议每 90 天轮换一次 API 密钥
4. **最小权限原则** - 每个服务账号只授予必要的权限
5. **监控访问日志** - 定期检查各平台的 API 访问日志

---

## 故障排除

### 问题 1: gh CLI 未安装
```bash
# macOS
brew install gh

# Windows
winget install --id GitHub.cli

# Linux
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh
```

### 问题 2: 权限不足
确保你的 GitHub Token 具有以下权限:
- `repo` - 访问仓库
- `admin:repo_hook` - 管理仓库钩子

### 问题 3: 验证失败
```bash
# 检查 gh 登录状态
gh auth status

# 重新登录
gh auth login

# 使用 PAT 登录
echo "YOUR_PAT" | gh auth login --with-token
```
