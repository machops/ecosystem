#!/bin/bash
# GitHub Actions 修復一鍵應用腳本
# 倉庫: codevantaio/eco-base

set -e

echo "========================================="
echo "  GitHub Actions 修復腳本"
echo "========================================="
echo ""

# 檢查是否在正確的目錄
if [ ! -d ".git" ]; then
    echo "❌ 錯誤: 請在倉庫根目錄運行此腳本"
    exit 1
fi

# 檢查遠程倉庫
REMOTE_URL=$(git remote get-url origin 2>/dev/null || echo "")
if [[ ! "$REMOTE_URL" =~ "codevantaio/eco-base" ]]; then
    echo "❌ 錯誤: 遠程倉庫不是 codevantaio/eco-base"
    echo "   當前: $REMOTE_URL"
    exit 1
fi

echo "✅ 倉庫檢查通過"
echo ""

# 創建修復分支
BRANCH_NAME="fix/actions-startup-failure-$(date +%s)"
echo "🔧 創建修復分支: $BRANCH_NAME"
git checkout -b "$BRANCH_NAME"
echo ""

# 備份原文件
echo "📦 備份原文件..."
cp .github/allowed-actions.yaml .github/allowed-actions.yaml.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
if [ -f ".github/workflows/codacy.yml" ]; then
    cp .github/workflows/codacy.yml .github/workflows/codacy.yml.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
fi
echo "✅ 備份完成"
echo ""

# 應用修復
echo "🔧 應用修復..."

# 修復 1: allowed-actions.yaml
cat > .github/allowed-actions.yaml << 'ALLOWED_ACTIONS_EOF'
#
# GitHub Actions Policy Configuration
# URI: eco-base://policy/github-actions
# Schema: v1
# FIXED: Added missing approved actions to resolve startup failures
#

policy:
  # Require all actions to be from approved organizations
  require_org_ownership: false
  
  # List of allowed organizations
  allowed_organizations:
    - indestructibleorg
    - actions
    - google-github-actions
    - azure
    - docker
    - github
    - codacy          # ADDED: For Codacy security scanning
    - aquasecurity    # ADDED: For Trivy vulnerability scanning
    - trufflesecurity # ADDED: For TruffleHog secret scanning
    - sigstore        # ADDED: For cosign signing
  
  # Require all actions to be pinned to full-length commit SHAs
  require_sha_pinning: false
  
  # Block tag references (e.g., @v1, @v2, @main)
  block_tag_references: false
  
  # Require Docker actions to be pinned to SHA256 digests
  require_docker_digest_pinning: false
  
  # Enforcement level: error | warning
  enforcement_level: warning

# Explicitly blocked actions (highest priority)
blocked_actions: []

# Approved GitHub-owned actions (exempt from org ownership check)
approved_actions:
  # Core GitHub Actions
  - actions/checkout
  - actions/upload-artifact
  - actions/download-artifact
  - actions/setup-python
  - actions/setup-node
  - actions/setup-go
  - actions/setup-java
  - actions/cache
  - actions/github-script
  - actions/labeler
  - actions/stale
  - actions/create-github-app-token
  - actions/attest-build-provenance
  - actions/upload-pages-artifact
  - actions/deploy-pages
  
  # GitHub CodeQL Actions (ADDED)
  - github/codeql-action/init
  - github/codeql-action/analyze
  - github/codeql-action/upload-sarif
  - github/codeql-action/autobuild
  
  # Google GitHub Actions (ADDED - explicitly approved)
  - google-github-actions/auth
  - google-github-actions/get-gke-credentials
  - google-github-actions/setup-gcloud
  
  # Security Scanning Actions (ADDED)
  - codacy/codacy-analysis-cli-action
  - codacy/codacy-coverage-reporter-action
  - aquasecurity/trivy-action
  - trufflesecurity/trufflehog
  
  # Supply Chain Security (ADDED)
  - sigstore/cosign-installer
ALLOWED_ACTIONS_EOF

echo "  ✅ 已更新 .github/allowed-actions.yaml"

# 修復 2: codacy.yml (如果存在)
if [ -f ".github/workflows/codacy.yml" ]; then
    # 檢查是否使用 tag 引用
    if grep -q "github/codeql-action/upload-sarif@v" .github/workflows/codacy.yml; then
        # 替換為 SHA 引用
        sed -i 's|github/codeql-action/upload-sarif@v[0-9]*|github/codeql-action/upload-sarif@6bb031afdd8eb862ea3fc1848194186e07677e1d # v3.28.11|g' .github/workflows/codacy.yml
        echo "  ✅ 已更新 .github/workflows/codacy.yml (使用 SHA 引用)"
    else
        echo "  ℹ️  codacy.yml 已使用 SHA 引用或不存在"
    fi
else
    echo "  ⚠️  .github/workflows/codacy.yml 不存在，跳過"
fi

echo ""
echo "📋 修復摘要:"
echo "  - 添加了 4 個新的允許組織"
echo "  - 添加了 10+ 個批准的 Actions"
echo "  - 修復了 codacy.yml 的 SHA 引用"
echo ""

# 顯示 git diff
echo "🔍 變更預覽:"
git diff --stat
echo ""

# 提交更改
echo "📝 提交更改..."
git add .github/allowed-actions.yaml
if [ -f ".github/workflows/codacy.yml" ]; then
    git add .github/workflows/codacy.yml
fi

git commit -m "fix(ci): resolve GitHub Actions startup failures

- Add missing approved actions to allowed-actions.yaml:
  - github/codeql-action/* (init, analyze, upload-sarif, autobuild)
  - codacy/codacy-analysis-cli-action
  - codacy/codacy-coverage-reporter-action
  - aquasecurity/trivy-action
  - trufflesecurity/trufflehog
  - sigstore/cosign-installer
  - google-github-actions/auth, get-gke-credentials

- Add missing organizations to allowed_organizations:
  - codacy, aquasecurity, trufflesecurity, sigstore

- Fix codacy.yml to use SHA-pinned github/codeql-action/upload-sarif

Fixes startup failures in:
- ci.yaml
- codacy.yml
- codeql.yml
- eco-deploy.yml
- pat-secret-scan.yml
- supply-chain-gate.yml
- weekly-chaos-drill.yml"

echo "✅ 提交完成"
echo ""

# 推送分支
echo "🚀 推送到遠程..."
git push origin "$BRANCH_NAME"
echo ""

echo "========================================="
echo "  ✅ 修復完成!"
echo "========================================="
echo ""
echo "下一步操作:"
echo "1. 訪問: https://github.com/codevantaio/eco-base/pulls"
echo "2. 創建 Pull Request: $BRANCH_NAME → main"
echo "3. 合併 PR 後，工作流將正常運行"
echo ""
echo "分支名稱: $BRANCH_NAME"
echo ""