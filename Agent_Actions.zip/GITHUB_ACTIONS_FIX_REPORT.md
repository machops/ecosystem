# GitHub Actions 工作流修复报告

## 仓库信息
- **仓库**: codevantaio/eco-base
- **分析日期**: 2025年
- **问题类型**: GitHub Actions 启动失败 (Startup Failure)

---

## 问题诊断总结

### 根本原因
GitHub Actions 工作流启动失败的根本原因是：**Actions 安全策略配置不完整**。

仓库配置了 `.github/allowed-actions.yaml` 文件来控制允许使用的 GitHub Actions，但该文件缺少多个工作流所依赖的第三方 Actions，导致工作流在启动时被拒绝。

### 错误信息示例
```
The action codacy/codacy-coverage-reporter-action@89d6c85cfafaec52c72b6c5e8b2878d33104c699 
is not allowed in codevantaio/eco-base because all actions must be from a repository 
owned by codevantaio or created by GitHub.
```

---

## 发现的问题清单

### 1. allowed-actions.yaml 配置不完整
**影响**: 所有工作流

**缺失的 approved_actions**:
| Action | 用途 | 使用工作流 |
|--------|------|-----------|
| `github/codeql-action/init` | CodeQL 初始化 | codeql.yml |
| `github/codeql-action/analyze` | CodeQL 分析 | codeql.yml |
| `github/codeql-action/upload-sarif` | SARIF 上传 | codacy.yml, eco-deploy.yml |
| `codacy/codacy-analysis-cli-action` | Codacy 分析 | codacy.yml |
| `codacy/codacy-coverage-reporter-action` | 覆盖率上传 | ci.yaml |
| `aquasecurity/trivy-action` | 漏洞扫描 | eco-deploy.yml |
| `trufflesecurity/trufflehog` | 密钥扫描 | pat-secret-scan.yml |
| `sigstore/cosign-installer` | 镜像签名 | supply-chain-gate.yml |
| `google-github-actions/auth` | GCP 认证 | weekly-chaos-drill.yml |
| `google-github-actions/get-gke-credentials` | GKE 凭证 | weekly-chaos-drill.yml |

**缺失的 allowed_organizations**:
- `codacy` - Codacy 安全扫描
- `aquasecurity` - Trivy 漏洞扫描
- `trufflesecurity` - TruffleHog 密钥扫描
- `sigstore` - Cosign 签名

### 2. codacy.yml 使用 Tag 引用而非 SHA
**问题**: `github/codeql-action/upload-sarif@v3` 使用了 tag 引用
**修复**: 更新为完整的 commit SHA

---

## 修复方案

### 修复 1: 更新 allowed-actions.yaml

添加所有必需的 Actions 到 approved_actions 列表，并扩展 allowed_organizations。

**关键变更**:
1. 添加 GitHub CodeQL Actions 到 approved_actions
2. 添加 Codacy Actions 到 approved_actions
3. 添加安全扫描 Actions (Trivy, TruffleHog) 到 approved_actions
4. 添加 Sigstore cosign 到 approved_actions
5. 添加 Google GitHub Actions 到 approved_actions
6. 扩展 allowed_organizations 包含 codacy, aquasecurity, trufflesecurity, sigstore

### 修复 2: 更新 codacy.yml

将 `github/codeql-action/upload-sarif@v3` 替换为带 SHA 的引用。

---

## 修复后的文件

### 文件 1: .github/allowed-actions.yaml

```yaml
#
# GitHub Actions Policy Configuration
# URI: eco-base://policy/github-actions
# Schema: v1
# FIXED: Added missing approved actions to resolve startup failures
#

policy:
  # Require all actions to be from approved organizations
  require_org_ownership: false
  
  # List of allowed organizations
  allowed_organizations:
    - indestructibleorg
    - actions
    - google-github-actions
    - azure
    - docker
    - github
    - codacy          # ADDED: For Codacy security scanning
    - aquasecurity    # ADDED: For Trivy vulnerability scanning
    - trufflesecurity # ADDED: For TruffleHog secret scanning
    - sigstore        # ADDED: For cosign signing
  
  # Require all actions to be pinned to full-length commit SHAs
  require_sha_pinning: false
  
  # Block tag references (e.g., @v1, @v2, @main)
  block_tag_references: false
  
  # Require Docker actions to be pinned to SHA256 digests
  require_docker_digest_pinning: false
  
  # Enforcement level: error | warning
  enforcement_level: warning

# Explicitly blocked actions (highest priority)
blocked_actions: []

# Approved GitHub-owned actions (exempt from org ownership check)
approved_actions:
  # Core GitHub Actions
  - actions/checkout
  - actions/upload-artifact
  - actions/download-artifact
  - actions/setup-python
  - actions/setup-node
  - actions/setup-go
  - actions/setup-java
  - actions/cache
  - actions/github-script
  - actions/labeler
  - actions/stale
  - actions/create-github-app-token
  - actions/attest-build-provenance
  - actions/upload-pages-artifact
  - actions/deploy-pages
  
  # GitHub CodeQL Actions (ADDED)
  - github/codeql-action/init
  - github/codeql-action/analyze
  - github/codeql-action/upload-sarif
  - github/codeql-action/autobuild
  
  # Google GitHub Actions (ADDED - explicitly approved)
  - google-github-actions/auth
  - google-github-actions/get-gke-credentials
  - google-github-actions/setup-gcloud
  
  # Security Scanning Actions (ADDED)
  - codacy/codacy-analysis-cli-action
  - codacy/codacy-coverage-reporter-action
  - aquasecurity/trivy-action
  - trufflesecurity/trufflehog
  
  # Supply Chain Security (ADDED)
  - sigstore/cosign-installer
```

### 文件 2: .github/workflows/codacy.yml

```yaml
# This workflow uses actions that are not certified by GitHub.
# They are provided by a third-party and are governed by
# separate terms of service, privacy policy, and support
# documentation.
# This workflow checks out code, performs a Codacy security scan
# and integrates the results with the
# GitHub Advanced Security code scanning feature.  For more information on
# the Codacy security scan action usage and parameters, see
# https://github.com/codacy/codacy-analysis-cli-action.
# For more information on Codacy Analysis CLI in general, see
# https://github.com/codacy/codacy-analysis-cli.

name: Codacy Security Scan

on:
  push:
    branches: [ "main" ]
  pull_request:
    # The branches below must be a subset of the branches above
    branches: [ "main" ]
  schedule:
    - cron: '44 12 * * 6'

permissions:
  contents: read

jobs:
  codacy-security-scan:
    permissions:
      contents: read # for actions/checkout to fetch code
      security-events: write # for github/codeql-action/upload-sarif to upload SARIF results
      actions: read # only required for a private repository by github/codeql-action/upload-sarif to get the Action run status
    name: Codacy Security Scan
    runs-on: ubuntu-latest
    steps:
      # Checkout the repository to the GitHub Actions runner
      - name: Checkout code
        uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2

      # Execute Codacy Analysis CLI and generate a SARIF output with the security issues identified during the analysis
      - name: Run Codacy Analysis CLI
        uses: codacy/codacy-analysis-cli-action@d840f886c4bd4edc059706d09c6a1586111c540b # v4.4.5
        with:
          # Check https://github.com/codacy/codacy-analysis-cli#project-token to get your project token from your Codacy repository
          # You can also omit the token and run the tools that support default configurations
          project-token: ${{ secrets.CODACY_PROJECT_TOKEN }}
          verbose: true
          output: results.sarif
          format: sarif
          # Adjust severity of non-security issues
          gh-code-scanning-compat: true
          # Force 0 exit code to allow SARIF file generation
          # This will handover control about PR rejection to the GitHub side
          max-allowed-issues: 2147483647

      # Upload the SARIF file generated in the previous step
      - name: Upload SARIF results file
        uses: github/codeql-action/upload-sarif@6bb031afdd8eb862ea3fc1848194186e07677e1d # v3.28.11
        with:
          sarif_file: results.sarif
```

---

## 实施步骤

### 步骤 1: 提交修复

```bash
# 1. 创建修复分支
git checkout -b fix/actions-startup-failure

# 2. 更新 allowed-actions.yaml
cp allowed-actions.yaml.fixed .github/allowed-actions.yaml

# 3. 更新 codacy.yml
cp codacy.yml.fixed .github/workflows/codacy.yml

# 4. 提交更改
git add .github/allowed-actions.yaml .github/workflows/codacy.yml
git commit -m "fix(ci): resolve GitHub Actions startup failures

- Add missing approved actions to allowed-actions.yaml:
  - github/codeql-action/* (init, analyze, upload-sarif)
  - codacy/codacy-analysis-cli-action
  - codacy/codacy-coverage-reporter-action
  - aquasecurity/trivy-action
  - trufflesecurity/trufflehog
  - sigstore/cosign-installer
  - google-github-actions/auth, get-gke-credentials

- Add missing organizations to allowed_organizations:
  - codacy, aquasecurity, trufflesecurity, sigstore

- Fix codacy.yml to use SHA-pinned github/codeql-action/upload-sarif

Fixes startup failures in:
- ci.yaml
- codacy.yml
- codeql.yml
- eco-deploy.yml
- pat-secret-scan.yml
- supply-chain-gate.yml
- weekly-chaos-drill.yml"

# 5. 推送并创建 PR
git push origin fix/actions-startup-failure
gh pr create --title "Fix GitHub Actions startup failures" --body "Fixes Actions policy configuration"
```

### 步骤 2: 验证修复

提交 PR 后，观察以下工作流是否成功启动：
- [ ] ci.yaml
- [ ] codacy.yml
- [ ] codeql.yml
- [ ] eco-deploy.yml
- [ ] pat-secret-scan.yml
- [ ] supply-chain-gate.yml
- [ ] weekly-chaos-drill.yml

---

## 预期结果

修复后，所有工作流应该能够：
1. ✅ 正常启动而不会被拒绝
2. ✅ PR 检查能够正常执行
3. ✅ 合并不会被阻断

---

## 附加建议

1. **考虑启用 SHA 固定**: 将 `require_sha_pinning` 设置为 `true` 以提高安全性
2. **定期审查**: 定期审查 allowed-actions.yaml 确保列表是最新的
3. **文档化**: 在添加新 Actions 时更新文档
