#!/bin/bash
# GitHub Secrets 配置脚本
# 仓库: codevantaio/eco-base
# 使用方法: bash configure-github-secrets.sh

set -e

REPO="codevantaio/eco-base"
echo "========================================="
echo "  GitHub Secrets 配置脚本"
echo "  仓库: $REPO"
echo "========================================="
echo ""

# 检查 gh CLI
if ! command -v gh &> /dev/null; then
    echo "❌ gh CLI 未安装"
    echo "请安装 GitHub CLI: https://cli.github.com/"
    exit 1
fi

# 检查登录状态
if ! gh auth status &> /dev/null; then
    echo "❌ 未登录 GitHub CLI"
    echo "请运行: gh auth login"
    exit 1
fi

echo "✅ GitHub CLI 已安装且已登录"
echo ""

# 配置 Secrets
echo "开始配置 Secrets..."
echo ""

# Google Cloud Secrets
echo "🔧 配置 Google Cloud Secrets..."
gh secret set GCP_PROJECT_ID --body "my-project-ops-1991" --repo $REPO
echo "  ✅ GCP_PROJECT_ID"

gh secret set GCP_SERVICE_ACCOUNT --body "eco-deploy-sa@my-project-ops-1991.iam.gserviceaccount.com" --repo $REPO
echo "  ✅ GCP_SERVICE_ACCOUNT"

gh secret set GCP_SA_KEY --body "29f5085c952ac8f3bc845358d123385ce365adb9" --repo $REPO
echo "  ✅ GCP_SA_KEY"

gh secret set GCP_OAUTH_CLIENT_ID --body "109929971358789976736" --repo $REPO
echo "  ✅ GCP_OAUTH_CLIENT_ID"

echo ""

# Cloudflare Secrets
echo "🔧 配置 Cloudflare Secrets..."
gh secret set CLOUDFLARE_API_TOKEN --body "lT5_7AldkQ4BDznsMsbioMwLoVe2kNTRno0NGzh_" --repo $REPO
echo "  ✅ CLOUDFLARE_API_TOKEN"

gh secret set CLOUDFLARE_ZONE_ID --body "3f10062913fe82ee54594594413c3d68" --repo $REPO
echo "  ✅ CLOUDFLARE_ZONE_ID"

gh secret set CLOUDFLARE_ACCOUNT_ID --body "2fead4a141ec2c677eb3bf0ac535f1d5" --repo $REPO
echo "  ✅ CLOUDFLARE_ACCOUNT_ID"

echo ""

# Supabase Secrets
echo "🔧 配置 Supabase Secrets..."
gh secret set SUPABASE_URL --body "https://yrfxijooswpvdpdseswy.supabase.co" --repo $REPO
echo "  ✅ SUPABASE_URL"

gh secret set SUPABASE_ANON_KEY --body "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlyZnhpam9vc3dwdmRwZHNlc3d5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA3MjYxNjMsImV4cCI6MjA4NjMwMjE2M30.R4gO5Kj5G0aYnvOE3N4D3gBN1Zu7fD9d31z99qW023I" --repo $REPO
echo "  ✅ SUPABASE_ANON_KEY"

gh secret set SUPABASE_SERVICE_KEY --body "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlyZnhpam9vc3dwdmRwZHNlc3d5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MDcyNjE2MywiZXhwIjoyMDg2MzAyMTYzfQ.-OGp0mC6K3iJzk5-oWl6LsbQpkBwk8yTPMa-hEL74MQ" --repo $REPO
echo "  ✅ SUPABASE_SERVICE_KEY"

echo ""

# Vercel Secrets
echo "🔧 配置 Vercel Secrets..."
gh secret set VERCEL_TOKEN --body "vcp_6Fqs6Vy6KzGw10mj7IJAuECgTSvz30DCC2AKnUl7NhZAOPqWZN3L40Iq" --repo $REPO
echo "  ✅ VERCEL_TOKEN"

echo ""

# Codacy Secrets
echo "🔧 配置 Codacy Secrets..."
gh secret set CODACY_PROJECT_TOKEN --body "af5e6a23e3134652bc96de5d50da09b6" --repo $REPO
echo "  ✅ CODACY_PROJECT_TOKEN"

echo ""

# SonarQube Secrets
echo "🔧 配置 SonarQube Secrets..."
gh secret set SONAR_TOKEN --body "sqco_Bfwi7qS47R8UCoU8hYgSHBraS68dpjt0KRbiTFzs7UcrShWwD69rx0LUcRs" --repo $REPO
echo "  ✅ SONAR_TOKEN"

echo ""

# GitHub Token
echo "🔧 配置 GitHub Token..."
gh secret set GITHUB_TOKEN --body "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" --repo $REPO
echo "  ✅ GITHUB_TOKEN"

echo ""
echo "========================================="
echo "  ✅ 所有 Secrets 配置完成!"
echo "========================================="
echo ""
echo "验证命令: gh secret list --repo $REPO"
